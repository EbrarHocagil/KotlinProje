package com.Itfaye_Guruplari.zmrtfaye

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.Itfaye_Guruplari.zmrtfaye.view.Izmir_yanginlar_list
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bt_yangnlar.setOnClickListener {
            val intent = Intent(this, Izmir_yanginlar_list::class.java)
            startActivity(intent)
        }
    }
}