package com.Itfaye_Guruplari.zmrtfaye.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.Itfaye_Guruplari.zmrtfaye.R
import kotlinx.android.synthetic.main.activity_main.*

class Izmir_yanginlar_list : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_izmir_yanginlar_list)


    }
}